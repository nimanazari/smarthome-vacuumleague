# Smart Home League — بازی + مپ 6

این پوشه بازی کامل است و **مپ 6 (مپ ۶ — خانه‌ی باز ۴خوابه · Open 4-bedroom house)** از قبل داخلش است.

1. روی **index.html** دوبار کلیک کن (هیچ نصبی لازم نیست؛ `serve.bat` هم کار می‌کند).
2. رده‌ات را انتخاب کن.
3. مپ 6 خودش در منوی نقشه با 📁 انتخاب شده است. بازی کن.

اگر ویندوز نداری: روی مک «Smart Home League (Mac).command» را باز کن؛ روی
لینوکس `python3 -m http.server 8801` در همین پوشه.

The complete game with map 6 built in: double-click serve.bat, pick your
division, the map is already selected.
