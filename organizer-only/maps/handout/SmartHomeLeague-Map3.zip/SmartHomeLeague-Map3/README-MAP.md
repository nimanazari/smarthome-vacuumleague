# Smart Home League — بازی + مپ 3

این پوشه بازی کامل است و **مپ 3 (مپ ۳ — خانه‌ی حیاط‌مرکزی · Courtyard house)** از قبل داخلش است.

1. روی **serve.bat** دوبار کلیک کن (هیچ نصبی لازم نیست).
2. مرورگر خودش http://localhost:8801/ را باز می‌کند؛ رده‌ات را انتخاب کن.
3. مپ 3 خودش در منوی نقشه با 📁 انتخاب شده است. بازی کن.

اگر ویندوز نداری: روی مک «Smart Home League (Mac).command» را باز کن؛ روی
لینوکس `python3 -m http.server 8801` در همین پوشه.

The complete game with map 3 built in: double-click serve.bat, pick your
division, the map is already selected.
